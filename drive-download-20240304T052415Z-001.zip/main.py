
from flask import Flask, request, render_template, session, redirect, url_for, flash
import sqlite3, os

app: Flask = Flask(__name__, static_url_path='/static')
app.secret_key = "123"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sqldbname = os.path.join(BASE_DIR, 'db', 'website.db')
#Mặc định gọi form search
from flask import session, redirect, url_for

@app.route('/')
def index():
    home_product_table_1 = load_data_1()
    home_product_table_2 = load_data_2()

    # Kiểm tra xem người dùng đã đăng nhập hay chưa
    if 'username' in session:
        username = session['username']
        return render_template('home.html', search_text="", products_1=home_product_table_1, products_2=home_product_table_2, logged_in=True, username=username)
    else:
        return render_template('home.html', search_text="", products_1=home_product_table_1, products_2=home_product_table_2, logged_in=False)

def load_data_1():
            # Khai bao bien de tro toi db
            conn = sqlite3.connect(sqldbname)
            cursor = conn.cursor()
            sqlcommand = ("Select * from storages where id < 21")
            cursor.execute(sqlcommand)
            data = cursor.fetchall()
            conn.close()
            return data

def load_data_2():
            # Khai bao bien de tro toi db
            conn = sqlite3.connect(sqldbname)
            cursor = conn.cursor()
            sqlcommand = ("Select * from storages where id > 21 and id < 41")
            cursor.execute(sqlcommand)
            data = cursor.fetchall()
            conn.close()
            return data

#Đối với phương thức Search
@app.route('/searchData', methods=['POST'])
def searchData():
    #Get data from Request
    search_text = request.form['searchInput']
    #Thay bang ham load du lieu tu DB
    product_table = load_data_from_db(search_text)
    print(product_table)
    return render_template('searchData.html', search_text=search_text, products=product_table)

def load_data_from_db(search_text):
        if search_text != "":
            # Khai bao bien de tro toi db
            conn = sqlite3.connect(sqldbname)
            cursor = conn.cursor()
            sqlcommand = ("Select * from storages where brand like '%")+search_text+ "%'"
            cursor.execute(sqlcommand)
            data = cursor.fetchall()
            conn.close()
            return data

@app.route("/cart/add", methods=["POST"])
def add_to_cart():
    #2. Get the product id and quantity from the form
    product_id = request.form["product_id"]
    quantity = int(request.form["quantity"])

    #3. get the product name and price from the database
    # or change the structure of shopping cart
    connection = sqlite3.connect(sqldbname)
    cursor = connection.cursor()
    cursor.execute("SELECT model, price, picture, details FROM storages WHERE id = ?",
                   (product_id,))
    #3.1. get one product
    product = cursor.fetchone()
    connection.close()

    #4. create a dictionary for the product
    product_dict = {
        "id": product_id,
        "name": product[0],
        "price": product[1],
        "quantity": quantity,
        "picture": product[2],
        'details': product[3]
    }
    #5. get the cart from the session or create an empty list
    cart = session.get("cart", [])

    #6. check if the product is already in the cart
    found = False
    for item in cart:
        if item["id"] == product_id:
            #6.1 update the quantity of the existing product
            item["quantity"] += quantity
            found = True
            break

    if not found:
        #6.2 add the new product to the cart
        cart.append(product_dict)
    #7. save the cart back to the session
    session["cart"] = cart

    #8. Flash success message
    flash('Sản phẩm đã được thêm vào giỏ hàng', 'success')

    #9. Redirect to the home page
    return redirect(url_for('index'))


@app.route("/viewcart", methods=["POST"])
def view_cart():
    # get the cart from the session or create an empty list
    # render the cart.html template and pass the cart
    current_cart = []
    if 'cart' in session:
        current_cart = session.get("cart", [])
    return render_template("cart.html", carts=current_cart)

@app.route("/cart/delete", methods=["POST"])
def delete_from_cart():
    # Nhận ID sản phẩm muốn xóa từ request
    product_id_to_delete = request.form.get("product_id")

    # Lấy giỏ hàng từ session hoặc tạo giỏ hàng mới nếu chưa có
    cart = session.get("cart", [])

    # Tìm và xóa sản phẩm từ giỏ hàng
    for i, product in enumerate(cart):
        if product["id"] == product_id_to_delete:
            del cart[i]
            break

    # Lưu giỏ hàng mới vào session
    session["cart"] = cart

    success_message = f"Đã xóa sản phẩm có ID: {product_id_to_delete} thành công."

    # Chuyển hướng người dùng đến trang giỏ hàng và trả về thông báo
    return redirect(url_for("view_cart", message=success_message))

@app.route("/viewAsusProducts", methods=["POST"])
def get_asus_products():
    product_table = view_asus_products()
    print(product_table)
    return render_template('asusProducts.html', products = product_table)
def view_asus_products():
    conn = sqlite3.connect(sqldbname)
    cursor = conn.cursor()
    sqlcommand = ("Select * from storages where brand = 'Asus'")
    cursor.execute(sqlcommand)
    data = cursor.fetchall()
    conn.close()
    return data

@app.route("/viewDellProducts", methods=["POST"])
def get_dell_products():
    product_table = view_dell_products()
    print(product_table)
    return render_template('dellProducts.html', products = product_table)
def view_dell_products():
    conn = sqlite3.connect(sqldbname)
    cursor = conn.cursor()
    sqlcommand = ("Select * from storages where brand = 'Dell'")
    cursor.execute(sqlcommand)
    data = cursor.fetchall()
    conn.close()
    return data

@app.route("/viewHPProducts", methods=["POST"])
def get_hp_products():
    product_table = view_hp_products()
    print(product_table)
    return render_template('hpProducts.html', products = product_table)
def view_hp_products():
    conn = sqlite3.connect(sqldbname)
    cursor = conn.cursor()
    sqlcommand = ("Select * from storages where brand = 'HP'")
    cursor.execute(sqlcommand)
    data = cursor.fetchall()
    conn.close()
    return data

@app.route("/viewLenovoProducts", methods=["POST"])
def get_lenovo_products():
    product_table = view_lenovo_products()
    print(product_table)
    return render_template('lenovoProducts.html', products = product_table)
def view_lenovo_products():
    conn = sqlite3.connect(sqldbname)
    cursor = conn.cursor()
    sqlcommand = ("Select * from storages where brand = 'Lenovo'")
    cursor.execute(sqlcommand)
    data = cursor.fetchall()
    conn.close()
    return data

@app.route('/login', methods=['GET', 'POST'])
def login():
    message = ''
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if check_exists(username,password):
            session['username'] = username
            return redirect(url_for('index'))
        else:
            message = 'Tên người dùng hoặc mật khẩu sai. Vui lòng thử lại.'
    return render_template('login.html', message=message)

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))

def check_exists(username, password):
    result = False
    conn = sqlite3.connect(sqldbname)
    cursor = conn.cursor()

    sqlcommand = "Select * from user where name = '"+username+"' and password = '"+password+"'"
    cursor.execute(sqlcommand)
    data = cursor.fetchall()
    print(type(data))
    if len(data)>0:
        result = True
    conn.close()
    return result

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        # Xử lý dữ liệu đăng ký ở đây
        # Ví dụ: Lấy thông tin từ form
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']

        if len(username) < 8:
            session['message'] = {'text': 'Tên người dùng phải có ít nhất 8 ký tự.', 'color': 'red'}
        elif len(password) < 8:
            session['message'] = {'text': 'Mật khẩu phải có ít nhất 8 ký tự.', 'color': 'red'}
        else:
            session['message'] = {'text': 'Đăng ký thành công!', 'color': 'green'}
            conn = sqlite3.connect(sqldbname)
            cursor = conn.cursor()

            # Kiểm tra xem tên người dùng đã tồn tại chưa
            cursor.execute("SELECT * FROM user WHERE name=?", (username,))
            existing_user = cursor.fetchone()

            if existing_user:
                conn.close()
                return "Tên người dùng đã tồn tại. Vui lòng chọn tên khác."

            # Thêm người dùng mới vào bảng users với mật khẩu không được băm
            cursor.execute("INSERT INTO user (name, password, email) VALUES (?, ?, ?)", (username, password, email))
            conn.commit()
            conn.close()
    return render_template('register.html')


@app.route('/product/<int:product_id>')
def view_product_details(product_id):
    product_details = get_product_details(product_id)
    return render_template('product_detail.html', product_details=product_details)

# Hàm mới để lấy chi tiết sản phẩm từ cơ sở dữ liệu
def get_product_details(product_id):
    conn = sqlite3.connect(sqldbname)
    cursor = conn.cursor()
    sqlcommand = "SELECT * FROM storages WHERE id = ?"
    cursor.execute(sqlcommand, (product_id,))
    product_details = cursor.fetchone()
    conn.close()
    return product_details

if __name__ == '__main__':
    app.run(debug=True)

